﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Arena.Core;
using Arena.DataLayer.Core;
using Arena.Utility;
using Arena.Custom.HDC.Twilio.Entity;

namespace Arena.Custom.HDC.Twilio
{
    public partial class SmsStatus : System.Web.UI.Page
    {
        private const String personDetailPageId = "7";


        protected void Page_Load(object sender, EventArgs e)
        {
            String smsSid = Request.Form["SmsSid"].ToString();
            String status = Request.Form["SmsStatus"].ToString().ToLower();
            SmsHistory history;


            //
            // Check if this is a received message.
            //
            if (status == "received")
            {
                LookupCollection validNumbers = new LookupCollection(new Guid("11B4ADEC-CB8C-4D01-B99E-7A0FFE2007B5"));
                String body = Request.Form["Body"].ToString();
                String from = Request.Form["From"].ToString();
                String to = Request.Form["To"].ToString();
                String baseUrl;
                StringBuilder sb = new StringBuilder();
                PersonCollection col = new PersonCollection();
                Lookup lkTo = null;

                //
                // Look for the twilio phone number, if not found ignore the incoming message.
                //
                to = TwilioSMS.CleanPhone(to);
                foreach (Lookup lk in validNumbers)
                {
                    if (lk.Active && to == TwilioSMS.CleanPhone(lk.Qualifier))
                    {
                        lkTo = lk;
                        break;
                    }
                }
                if (lkTo == null)
                    return;

                //
                // Load all person records that match the phone number.
                //
                from = TwilioSMS.CleanPhone(from);
                if (from.StartsWith("1"))
                    col.LoadByPhone(from.Substring(1));
                else
                    col.LoadByPhone(from);

                //
                // Set the base url.
                //
                baseUrl = ArenaContext.Current.AppSettings["ApplicationURLPath"];
                if (!baseUrl.EndsWith("/"))
                    baseUrl = baseUrl + "/";
                baseUrl = String.Format("{0}default.aspx?page={1}", baseUrl, personDetailPageId);

                //
                // If there is a valid e-mail address to forward the text to then build up an e-mail
                // message and send an e-mail.
                //
                if (!String.IsNullOrEmpty(lkTo.Qualifier2))
                {
                    try
                    {
                        sb.AppendFormat("<p>Received a text message from {0} to {1} ({2})</p>", from, to, lkTo.Value);
                        sb.AppendFormat("<p>Message: {0}</p>", body);

                        if (col.Count > 0)
                        {
                            sb.Append("<p>Possibly received from:<br /><ul>");
                            foreach (Person p in col)
                            {
                                sb.AppendFormat("<li><a href=\"{0}&guid={1}\">{2}</a></li>", baseUrl, p.PersonGUID.ToString(), Server.HtmlEncode(p.FullName));
                            }
                            sb.Append("</ul></p>");
                        }

                        ArenaSendMail.SendMail(String.Empty, String.Empty, lkTo.Qualifier2, "Received SMS message", sb.ToString());
                    }
                    catch (System.Exception ex)
                    {
                        try
                        {
                            new Arena.DataLayer.Core.ExceptionHistoryData().AddUpdate_Exception(ex, ArenaContext.Current.Organization.OrganizationID,
                                "HDC.Twilio", ArenaContext.Current.ServerUrl);
                        }
                        catch { }
                    }
                }

                //
                // If there is an auto-reply message in the lookup then send back that message.
                //
                if (!String.IsNullOrEmpty(lkTo.Qualifier8))
                {
                    try
                    {
                        int len = lkTo.Qualifier8.Length;

                        if (len > 160)
                            len = 160;
                        Response.Clear();
                        Response.ContentType = "text/plain";
                        Response.Write(lkTo.Qualifier8.Substring(0, len));
                        Response.End();
                    }
                    catch (System.Exception ex)
                    {
                        try
                        {
                            new Arena.DataLayer.Core.ExceptionHistoryData().AddUpdate_Exception(ex, ArenaContext.Current.Organization.OrganizationID,
                                "HDC.Twilio", ArenaContext.Current.ServerUrl);
                        }
                        catch { }
                    }
                }

                //
                // If only one person was found matching the phone number, record in person history.
                //
                if (col.Count == 1)
                {
                    try
                    {
                    }
                    catch (System.Exception ex)
                    {
                        try
                        {
                            new Arena.DataLayer.Core.ExceptionHistoryData().AddUpdate_Exception(ex, ArenaContext.Current.Organization.OrganizationID,
                                "HDC.Twilio", ArenaContext.Current.ServerUrl);
                        }
                        catch { }
                    }
                }
            }
            else
            {
                //
                // This (should be) a status response to an outgoing message.
                //
                history = new SmsHistory(smsSid);
                if (history.SmsHistoryId != -1)
                {
                    try
                    {
                        if (status == "sent")
                        {
                            new PersonCommunicationData().SavePersonCommunication(history.CommunicationId, history.PersonId, DateTime.Now, "Success");
                        }
                        else
                        {
                            new PersonCommunicationData().SavePersonCommunication(history.CommunicationId, history.PersonId, DateTime.Now, "Failed");
                        }
                    }
                    catch (System.Exception)
                    {
                    }

                    history.Delete();
                }
            }
        }
    }
}